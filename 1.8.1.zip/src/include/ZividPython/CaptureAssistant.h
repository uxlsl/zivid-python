#pragma once

#include <ZividPython/Wrappers.h>

namespace ZividPython::CaptureAssistant
{
    void wrapAsSubmodule(pybind11::module &dest);
} // namespace ZividPython::CaptureAssistant
