#pragma once

#include <ZividPython/Wrappers.h>

namespace ZividPython::HandEye
{
    void wrapAsSubmodule(pybind11::module &dest);
} // namespace ZividPython::HandEye
