#pragma once

#include <ZividPython/Wrappers.h>

namespace ZividPython::HDR
{
    void wrapAsSubmodule(pybind11::module &dest);
} // namespace ZividPython::HDR
