#!/bin/bash

export CXX=gcc
export CXXFLAGS="-Wall -Wextra -Werror"
